document.addEventListener('DOMContentLoaded', () => {
    const buttons = document.querySelectorAll('button');
    buttons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const productName = e.target.parentElement.querySelector('h2').innerText;
            alert(productName + " added to cart!");
            btn.innerText = "Added";
            btn.style.backgroundColor = "#ddd";
        });
    });
});