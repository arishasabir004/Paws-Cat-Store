#include <iostream>
#include "../include/Store.h"

using namespace std;

int main() {
    Store myStore;
    myStore.loadInventory();

    string type, breed, cat;
    int age;

    cout << "Welcome to Paws Store\nBuy CAT or ACCESSORY?: ";
    cin >> type;

    if (type == "CAT" || type == "cat") {
        cout << "Breed: "; cin >> breed;
        cout << "Category: "; cin >> cat;
        cout << "Age: "; cin >> age;
        
        double p = myStore.calculateCatPrice(breed, cat, age);
        if (p > 0) {
            cout << "Price: " << p << endl;
            myStore.logSale(breed, p);
        } else {
            cout << "Not Found." << endl;
        }
    }
    return 0;
}