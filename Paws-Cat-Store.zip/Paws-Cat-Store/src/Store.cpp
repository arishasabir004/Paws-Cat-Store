#include "../include/Store.h"
#include <fstream>
#include <iostream>
#include <algorithm>

using namespace std;

string toUpper(string str) {
    transform(str.begin(), str.end(), str.begin(), ::toupper);
    return str;
}

void Store::loadInventory() {
    // In a real 3rd year project, you'd read the CSV here. 
    // For now, we populate it with your original data.
    catInventory.push_back(Cat("PERSIAN", "KITTEN", 2, 8, 39000));
    catInventory.push_back(Cat("BRITISH", "KITTEN", 2, 8, 43000));
    accInventory.push_back(Accessory("LOW", "Litter box & Sand", 1500));
}

double Store::calculateCatPrice(string b, string c, int age) {
    b = toUpper(b); c = toUpper(c);
    for (auto &cat : catInventory) {
        if (cat.breed == b && cat.category == c && age >= cat.minAge && age <= cat.maxAge) {
            return cat.price;
        }
    }
    return 0;
}

void Store::logSale(string item, double price) {
    ofstream outFile("data/sales.txt", ios::app);
    outFile << "Sold: " << item << " | Price: " << price << endl;
    outFile.close();
}