#ifndef UTILS_H
#define UTILS_H

#include <string>
#include <algorithm>

using namespace std;

class Utils {
public:
    static string toUpper(string str) {
        transform(str.begin(), str.end(), str.begin(), ::toupper);
        return str;
    }
};

#endif