#ifndef CAT_H
#define CAT_H

#include <string>
using namespace std;

class Cat {
public:
    string breed;
    string category;
    int minAge;
    int maxAge;
    double price;

    Cat(string b, string c, int minA, int maxA, double p) 
        : breed(b), category(c), minAge(minA), maxAge(maxA), price(p) {}
};

#endif