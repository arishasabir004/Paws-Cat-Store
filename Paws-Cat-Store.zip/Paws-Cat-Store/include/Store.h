#ifndef STORE_H
#define STORE_H

#include <vector>
#include "Cat.h"
#include "Accessory.h"

class Store {
private:
    vector<Cat> catInventory;
    vector<Accessory> accInventory;

public:
    void loadInventory();
    double calculateCatPrice(string breed, string category, int age);
    double calculateAccPrice(string packageName);
    void logSale(string item, double price);
};

#endif