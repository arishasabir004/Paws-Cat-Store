#ifndef ACCESSORY_H
#define ACCESSORY_H

#include <string>
using namespace std;

class Accessory {
public:
    string packageName;
    string description;
    double price;

    Accessory(string name, string desc, double p) 
        : packageName(name), description(desc), price(p) {}
};

#endif